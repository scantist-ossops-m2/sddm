<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="da">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation>Tryk for at logge ind</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation>%1 (Wayland)</translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Advarsel, Caps Lock er slået til!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Log ind</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Indlogning fejlede</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Indlogning lykkedes</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Adgangskode</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Indtast dit brugernavn og adgangskode</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Vælg din bruger og indtast adgangskode</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Genstart</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Luk ned</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Brugernavn</translation>
    </message>
    <message>
        <source>Welcome to %1</source>
        <translation>Velkommen til %1</translation>
    </message>
</context>
</TS>
