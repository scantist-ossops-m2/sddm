<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Üdvözöljük - %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Figyelem: a Caps Lock BE van kapcsolva!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Nézet</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Bejelentkezés</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Bejelentkezés sikertelen</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Sikeres bejelentkezés</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Jelszó</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Írja be a felhasználónevét és a jelszavát</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Újraindítás</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Munkamenet</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Leállítás</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Felhasználónév</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Válassza ki a felhasználónevét és írja be a jelszavát</translation>
    </message>
</context>
</TS>
