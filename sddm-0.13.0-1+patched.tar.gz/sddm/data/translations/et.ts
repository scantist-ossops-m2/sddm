<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="et">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>%1 tervitab</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Hoiatus, Caps Lock on SEES!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Paigutus</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Logi sisse</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Sisselogimine ebaõnnestus</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Sisselogimine õnnestus</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasõna</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Sisesta kasutajanimi ja salasõna</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Taaskäivitamine</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Seanss</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Seiskamine</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Kasutajanimi</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Vali kasutaja ja sisesta salasõna</translation>
    </message>
</context>
</TS>
