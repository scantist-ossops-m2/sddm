<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Bienvenido a %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>¡Atención, el bloqueo de mayúsculas está activado!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Layout</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Inicio de sesión fallido</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Inicio de sesión correcto</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Ingrese su usuario y contraseña</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Sesión</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Seleccione su usuario e ingrese su contraseña</translation>
    </message>
</context>
</TS>
