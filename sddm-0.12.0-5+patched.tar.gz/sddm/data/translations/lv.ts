<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="lv">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Laipni Lūdzam %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Brīdinājums, ir ieslēgti Lielie Burti!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Tastatūras izkārtojums</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Ienākt</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Pieteikšanās neizdevās</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Pieteikšanās izdevās</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Parole</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Ievadiet savu lietotājvārdu un paroli</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Atsāknēt</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Sesija</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Izslēgt</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Lietotāja vārds</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Izvēlieties savu lietotāju un ievadiet paroli</translation>
    </message>
</context>
</TS>
