<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="is">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation>Smelltu til þess að innskrá</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation>%1 (Wayland)</translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Velkomin(n) í %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Athugið, hástafalás er virkur!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Útlitssnið</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Innskrá</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Innskráning tókst ekki</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Innskráning tókst</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Lykilorð</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Sláðu inn notandanafn og lykilorð</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Endurræsa</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Seta</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Slökkva</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Notandanafn</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Veldu notandann þinn og sláðu inn lykilorð</translation>
    </message>
</context>
</TS>
