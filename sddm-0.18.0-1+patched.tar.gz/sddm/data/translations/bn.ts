<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bn">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation>লগইন করতে চাপুন</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>%1এ স্বাগতম</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>সতর্কতা, ক্যাপ লক চালু আছে!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translatorcomment>Literally it means.গঠনপ্রণালী</translatorcomment>
        <translation>লেআউট</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>লগইন</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>লগইন ব্যর্থ</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>লগইন সফল</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>পাসওয়ার্ড</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>আপনার ব্যবহারকারী নাম এবং পাসওয়ার্ড প্রবেশ করুন</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translatorcomment>It is hard to translate as it means start over the system.</translatorcomment>
        <translation>রিবুট</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>সেশন</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translatorcomment>কাজ বন্ধ হওয়া</translatorcomment>
        <translation>শাটডাউন</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>ব্যবহারকারীর নাম</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>আপনার ব্যবহারকারী নাম বাছাই করুন এবং পাসওয়ার্ড প্রবেশ করুন</translation>
    </message>
</context>
</TS>
